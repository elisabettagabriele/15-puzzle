"use strict";
var attempts = 0;
var pieces;
function init(){
    //html validator
    var a = document.createElement('a'); 
    a.href = "https://validator.w3.org/";
    var img = document.createElement("img");
    img.src = "images/w3c-html.png";
    a.append(img);
    document.body.append(a);
    
    //css validator
    var a1 = document.createElement('a'); 
    a1.href = "https://jigsaw.w3.org/css-validator/";
     var img1 = document.createElement("img");
    img1.src = "images/w3c-css.png";
     a1.append(img1);
    document.body.append(a1);
    
    //js validator
    var a2 = document.createElement('a'); 
    a2.href = "https://www.jslint.com/";
     var img2 = document.createElement("img");
    img2.src = "images/js%20pic.PNG";
    img2.style.width = "88px";
    img2.style.height = "31px";
     a2.append(img2);
    document.body.append(a2);
    
    
   
    var paras = document.querySelectorAll("p");
    
    for (var h = 0; h< paras.length; h++){
        paras[h].classList.add("para");   //making the font cursive //my computer doesnt have this
    }
    pieces = document.getElementsByTagName("span");
    for(var w = 0; w < pieces.length; w++){
        //every time you click attemps++
        pieces[w].onclick = moves;
        
    }    
    
    var trigger = document.getElementById("shufflebutton");
    trigger.onclick = shuffle;
    //as long as you dont click it go to second();

}
    

var t0;
var t1;
function moves(){
    t0 = performance.now();
    attempts++;
    
    if (moveable(this)){  
        var currenttop = parseInt(this.style.top);
        var currentleft = parseInt(this.style.left);
        var b = document.querySelector(".blank");
        this.style.top = parseInt(b.style.top) + 'px';
        this.style.left = parseInt(b.style.left) + 'px';
        b.style.top = currenttop + 'px';
        b.style.left = currentleft + 'px'; 
        var temp = b.id;
        b.id = this.id;
        this.id = temp;    
            
        }
        if (attempts > 1){
       
        checker();
    } 
       
}


function moveable(tiling){
    var need2 = document.querySelectorAll("mover");
    for (var g = 0; 0 < need2.length; g++){
        need2[g].classList.remove("mover");
    }   
    var nullcount = 0;
    var counter = 0;
    var need = neighbors(tiling);
    
  
    for (var v = 0; v < need.length; v++){
    
        if (need[v] === null){
            need[v] = 0;
        }
    }
    
    for (var z = 0; z < need.length; z++){
         
        if(need[z].className == "blank"){
            
            need[z].classList.remove("mover");
             counter += 1;
            
        }
    }
   
    for (var r = 0; r < need.length; r++){
        if (need[r].className == "mover class1 nums"){
            counter++;
            need[r].classList.remove("mover");
                     
            
        }
    }
        
        if (counter > 0){
            return true;
        }
        else{
            return false;
        }
  
}




function neighbors(tiling2){
    var listers = [];
    if (tiling2 === null){
        tiling2 = 0;
    } 
    
    var row = parseInt(tiling2.style.top)/100;
    var column = parseInt(tiling2.style.left)/100;
   
    var top = document.getElementById("tile-" + (row-1) + "-" + column);     
    var left = document.getElementById("tile-" + row + "-" + (column-1));
    var right = document.getElementById("tile-" + row + "-" + (column+1));
    var bottom = document.getElementById("tile-" + (row+1) +"-" + column);
    listers.push(top);
    listers.push(left);
    listers.push(right);
    listers.push(bottom);
    return listers;
    
}
    


function second(){
    for (var i = 0; i < 4; i++){
        for(var j = 0; j < 4; j++){
            var tiles = document.createElement("span");
            tiles.classList.add("class1");
            tiles.id = "tile-" + j + "-" + i;
            tiles.style.left = i * 100 + "px";
            tiles.style.top = j * 100 + "px";
            tiles.style.backgroundPosition =  "-" + i * 100 + "px " + "-" + j * 100 +"px";
            tiles.innerHTML = j * 4 + i + 1;
            tiles.classList.add("nums");
            document.getElementById("puzzlearea").appendChild(tiles);
            if ((i+ 1) * (j + 1) == 16){
                tiles.innerHTML = "";
                //last tile blank
                tiles.className = "blank";
            }
            
            tiles.addEventListener("mouseover", color);
            tiles.addEventListener("mouseleave", color2);

        }
    }
    init();
    
}



function shuffle(){
    var blanky = document.querySelector(".blank");
    var neighbors2 = neighbors(blanky);
    for (var d = 0; d < neighbors2.length; d++){
    
        if (neighbors2[d] === null){
            neighbors2[d] = 0;
        }
    }
    
   
   for (var l = 0; l < 1001; l++){
           //pick a number between 0 and 4
           var rando = Math.floor(Math.random() * 4);
          
        if ((neighbors2[rando]) == 0){
            continue;
        }
                     
        var currenttop2 = parseInt(neighbors2[rando].style.top);
        var currentleft2 = parseInt(neighbors2[rando].style.left);
        
        neighbors2[rando].style.top = parseInt(blanky.style.top) + 'px';
        neighbors2[rando].style.left = parseInt(blanky.style.left) + 'px';
        blanky.style.top = currenttop2 + 'px';
        blanky.style.left = currentleft2 + 'px'; 
        
        var temp2 = blanky.id;
        blanky.id = neighbors2[rando].id;
        neighbors2[rando].id = temp2;
      
       }
  
}



function color(){
    var neighbors3 = neighbors(this);
  
    for (var e = 0; e < 4; e++){
    
        if (neighbors3[e] === null){
            neighbors3[e] = 0;
        }
    }
    
    for (var e1 = 0; e1 < 4; e1++){
        if (neighbors3[e1].className == "blank"){
            
            this.style.color = "red";
            this.style.borderColor = "red";
            this.classList.add("pointer");
            
}
}
}


function color2(){
    var neighbors4 = neighbors(this);
  
    for (var q1 = 0; q1 < 4; q1++){
    
        if (neighbors4[q1] === null){
            neighbors4[q1] = 0;
        }
    }
   
   for (var e2 = 0; e2 < 4; e2++){
        if (neighbors4[e2].className == "blank"){
            
            this.style.color = "";
            this.style.borderColor = "";
            this.classList.remove("pointer");
}
    
}
    }

var at;
function checker(){
    at = ["tile-0-0", "tile-1-0", "tile-2-0", "tile-3-0", "tile-0-1", "tile-1-1", "tile-2-1", "tile-3-1", "tile-0-2", "tile-1-2", "tile-2-2", "tile-3-2", "tile-0-3", "tile-1-3", "tile-2-3", "tile-3-3"];
   
     for (var jjs = 0; jjs < at.length; jjs++){
        var comparing2 = at[jjs];
        
    }
    
    var newTiles = document.querySelectorAll("span");
    for (var rr = 0; rr < newTiles.length; rr++){
        var comparing1 = newTiles[rr].id; 
        
    }
   
        if (comparing1 == comparing2){
            //THE PLAYER WINS!!!!!
            t1 = performance.now();
            var placement = document.querySelector("h1");
            var empty = document.createElement("div");
            //GAME TIMER ADDED HERE
            //TOTAL SECONDS NEEDED
            var finalAns = t1-t0;
            var text = document.createTextNode("Congratulations, you won! " + "You took you this many seconds: " + finalAns +
                                              " and it took this many tries " + attempts);
            empty.appendChild(text);
            placement.appendChild(empty);
            
        }
    }
           
    
    
        
    
window.onload = second;




